
Front-End Developer Assignment - React JS Timeline Chart
Overview
This project involves building a responsive timeline chart using React (v18), Node (v20), and Material UI. The timeline should have various views (Month, 2-week, 1-week, 2-day, 1-day), a Today button, Next and Previous buttons, and should display user entries in different colors. The data for the chart is provided in the data.json file.

Requirements
Build a timeline chart with Month, 2-week, 1-week, 2-day, and 1-day views.
Implement logic for the Today button to show the current view based on the selected filter.
If the current filter is Month, show the current month view.
If the current filter is Week, show the current week view.
If the current filter is Day, show the current day view.
Include Next and Previous buttons for easy navigation.
Display each user entry in different colors.
Ensure the chart is mobile-responsive.
Use the Material UI library for designing.
Handle empty views by displaying each layer as empty if no data is available for the selected date range.
Tech Stack
React (v18)
Node (v20)
Material UI
Chart library (of your choice)
Getting Started
Clone the repository.
Install dependencies using npm install.
Run the application using npm start.
Open the application in your browser at http://localhost:3000.
Project Structure
/src: Contains React components, styles, and logic.
/public: Contains static assets and data.json.
/components: Store React components.
Data Structure
The data.json file contains the required data for rendering the timeline chart.
Design Considerations
The use of Material UI components for consistent and responsive design.
Utilize a chart library for rendering the timeline efficiently.
Development Guidelines
Follow React and Material UI best practices.
Ensure clean and modular code.
Implement responsive design principles for a seamless experience on various devices.
Future Improvements
Consider additional features like user authentication and data editing.
Optimize performance for larger datasets.
Enhance user interaction and visual feedback.

GitHub Link for the project: 